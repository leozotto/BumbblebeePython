$('#input').on('keypress', function (e) {
    if (e.which == 13) {
        manageDOM();
    }
});

let message, response;

function manageDOM() {
    if ($("input").val()) {
        mensagem = popInput();
        addContent(mensagem, 'user message');
        textValue = buscar(message);
        // content add at 'buscar' function mensagem ajax structure
    }
}

function popInput() {
    let val = $("input").val();
    $("input").val('');
    return val;
}

function buscar(message) {
    $.ajax({
        url: 'http://localhost:5000/bot/' + message,
        dataType: 'json',
        type: 'get',
        cache: false,
        success: (data) => {
            $(data.mensagens).each((i, mensagem) => {
                addContent(mensagem.resposta, 'bot message');;
            })
        },
    });
};

function addContent(textValue, userClass) {
    $("ul").append("<li class='" + userClass + "'><p>" + textValue + "</p></li>");
    adjusteFocus();
}

function adjusteFocus() {
    $(".content").scrollTop(999999);
}
