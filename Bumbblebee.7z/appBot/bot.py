from chatterbot import ChatBot
from chatterbot.trainers import ChatterBotCorpusTrainer, ListTrainer

bot = ChatBot('Bumblebee',
              logic_adapters=[
                  {
                      'import_path': 'chatterbot.logic.BestMatch',
                      'default_response': 'desculpe, mas ainda não sou capaz de responder essa questão, envie um email para xx@xxxxxxxxxxxxxx.com',
                      'maximum_similarity_threshold': 0.30
                  }

              ])

ChatterBotCorpusTrainer(bot).train(
    "chatterbot.corpus.portuguese.conversations")
ListTrainer(bot).train([
    'oi',
    'oi, tudo bem?',

    'tudo e com você?',
    'estou bem tambem, qual e o seu nome?',

    'meu nome é',
    'olá eu sou Bumblebee, qual é o seu nome?',

    'preciso de sua ajuda',
    'olá como posso ajudar',

    'ainda não posso ajudar, envie um email para xx@xxxxxxxxxxxxxx.com',
    'eu fui desenvolvido para ajudar-lhe',

    'qual é o seu nome?',
    'meu nome é Bumblebee, filho de Optimus Prime',

    '',
    'não temos essas história',

    'me recomenda uma leitura',
    'recomendo a leitura de One Piece',

    'me recomenda uma historia',
    'recomendo a leitura de Dragon ball super',

    'me recomenda uma leitura',
    'recomendo a leitura de Naruto',

    'me recomenda uma historia',
    'recomendo a leitura de Homem Aranha',

    'me recomenda uma leitura',
    'recomendo a leitura de Os vingadores',

    'me recomenda uma historia',
    'recomendo a leitura de Boku no Hero',

    'me recomenda uma leitura',
    'recomendo a leitura de One Punch Man',

    'me recomenda uma historia',
    'recomendo a leitura de Shingeki no Kyojin',

    'me recomenda uma leitura',
    'recomendo a leitura de Turma da Mônica',

    'me recomenda uma historia',
    'recomendo a leitura de Turma da Mônica Jovem',

    'me recomenda uma leitura',
    'recomendo a leitura de Static Shock',

    'me recomenda uma historia',
    'recomendo a leitura de Capitão América',

    'me recomenda uma leitura',
    'recomendo a leitura de Homem de ferro',

    'me recomenda uma historia',
    'recomendo a leitura de Mulher Maravilha',

    'me recomenda uma leitura',
    'recomendo a leitura de Cavalheiros do Zodiaco',

    'me recomenda uma historia',
    'recomendo a leitura de Quarteto Fantástico',

    'me recomenda uma leitura',
    'recomendo a leitura de X-Men',

    'me recomenda uma historia',
    'recomendo a leitura de Star Wars',

    'me recomenda uma leitura',
    'recomendo a leitura de Superman',

    'me recomenda uma historia',
    'recomendo a leitura de Homem formiga',

    'me recomenda uma leitura',
    'recomendo a leitura de Watchmen, de Alan Moore e David Gibbons',

    'me recomenda uma historia',
    'recomendo a leitura de Demolidor - A queda de Murdock',

    'me recomenda uma leitura',
    'recomendo a leitura de Batman ',
])

#bot.read_only = True


def get_bot_response(request):
    return str(bot.get_response(request))
