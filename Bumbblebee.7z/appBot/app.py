from flask import Flask, jsonify
from flask_cors import CORS, cross_origin
from .bot import get_bot_response

app = Flask(__name__)
CORS(app, resources={"/bot/*": {"origins": "*"}})


@app.route('/bot/<string:message>', methods=['GET', 'POST'])
@cross_origin()
def get(message):
    return jsonify({'mensagens': [
        {'resposta': get_bot_response(message)},
    ]})


if __name__ == '__main__':
    app.run(debug=True)